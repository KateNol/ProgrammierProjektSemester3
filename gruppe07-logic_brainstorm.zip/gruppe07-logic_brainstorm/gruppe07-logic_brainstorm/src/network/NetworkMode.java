package network;

public enum NetworkMode {
    SERVER,
    CLIENT
}
