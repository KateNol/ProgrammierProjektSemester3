package network.internal;

public enum MessageMode {
    SEND,
    RECEIVE
}
