package internal;

public enum ServerMode {
    HOST,
    CLIENT
}
