package internal;

public enum NetworkMode {
    ONLINE,
    OFFLINE
}
