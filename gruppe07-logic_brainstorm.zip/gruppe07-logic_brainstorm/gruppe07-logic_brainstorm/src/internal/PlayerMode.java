package internal;

public enum PlayerMode {
    HUMAN,
    COMPUTER
}
