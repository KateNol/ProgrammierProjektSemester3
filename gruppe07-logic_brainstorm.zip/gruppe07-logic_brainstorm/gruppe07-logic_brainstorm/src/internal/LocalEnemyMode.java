package internal;

public enum LocalEnemyMode {
    HUMAN,
    COMPUTER
}
